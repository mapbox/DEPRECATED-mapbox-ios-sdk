//
//  RMTileLoadingView.h
//  MapView
//
//  Created by Justin R. Miller on 8/15/12.
//  Copyright 2012 MapBox.
//

#import <UIKit/UIKit.h>

@interface RMLoadingTileView : UIScrollView

@property (nonatomic, assign) BOOL mapZooming;

@end
